/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Charles Vestal
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Felucca memory map.
 * Code + constants execute in place from XIP (app.bin offset 0 = 0x02000120).
 * 0x01C00000..0x01C06000 holds .ram_text (code that must run while the flash
 * is busy: the flash driver); 0x01C06000..0x01C08000 stays for RAM-run debug.
 * RAM  : .data/.bss (96 KiB)
 * POOL : big zero-initialised buffers (FX lines, canvases), section .pool
 * STACKS with 256-byte guard bands; NOINIT survives resets and UBOOT entry.
 * 0x01C7FD50.. is reserved: boot_info, boot-state mailbox, vector table. */
MEMORY
{
    XIP    (rx)  : ORIGIN = 0x02000120, LENGTH = 0x8DFBC
    RAMTEXT (rwx): ORIGIN = 0x01C00000, LENGTH = 0x6000
    DEBUGRAM (rw): ORIGIN = 0x01C06000, LENGTH = 0x2000
    RAM    (rwx) : ORIGIN = 0x01C08000, LENGTH = 96K
    POOL   (rw)  : ORIGIN = 0x01C20000, LENGTH = 0x54000
    NOINIT (rw)  : ORIGIN = 0x01C7C000, LENGTH = 0x3D50
}
SECTIONS
{
    /* JieLi's BT code and constants run from XIP, as in their SDK (sdk_ld_sfc.c); .volatile_ram_code
     * and the radio trim (*.rf_trim, CONFIG_RF_TRIM_CODE_AT_RAM in their demos) run from RAM: the trim
     * draws ~500 ms of high current, and fetching from the flash meanwhile corrupts what is read
     * (the crashes 0.7 s into every BT start, fm1-ble notes/03-05) */
    .text : { KEEP(*(.text.crt0)) *(.text*) *(.rodata*)
              *(.bt_stack_code .ble_sm_code .hci_controller_code .ble_hci_code .ble_att_code .ble_db_code
                .classic_lmp_code .link_bulk_code .classic_rf_code .lmp_irq_code .ble_gatt_code .ble_ll_code
                .ble_rf_code .bt_rf_code .hci_interface_code .vendor_manager_code .device_manager_code)
              *(.*_const)
              . = ALIGN(4); _etext = .; } > XIP
    .ram_text : { _rt_start = .; KEEP(*(.ram_text*)) *(.volatile_ram_code) *(*.rf.text.cache.L2.rf_trim)
                  . = ALIGN(4); _rt_end = .; } > RAMTEXT AT > XIP
    _rt_load = LOADADDR(.ram_text);
    /* TEST30: the single shared native-voice hot loop executes from SRAM.
     * This sits immediately after .ram_text so the existing second PC guard
     * can cover both executable SRAM sections as one contiguous range. */
    .voice_hot : { _voice_hot_start = .; KEEP(*(.voice_hot*)) . = ALIGN(4); _voice_hot_end = .; } > RAMTEXT AT > XIP
    _voice_hot_load = LOADADDR(.voice_hot);
    /* Exact compact native-reverb history. These are NOLOAD: valid-history
     * counters make stale SRAM unreadable after boot/reset. DEBUGRAM was
     * previously reserved only for RAM-run debugging; production audio now
     * uses most of it while leaving CPU stacks untouched. */
    .reverb_rt (NOLOAD) : { . = ALIGN(4); *(.reverb_rt*) . = ALIGN(4); } > RAMTEXT
    .reverb_debug (NOLOAD) : { . = ALIGN(4); *(.reverb_debug*) . = ALIGN(4); } > DEBUGRAM
    .data : { . = ALIGN(4); _data_start = .; *(.data*) *(.sdata*) *(.*_data) . = ALIGN(4); _data_end = .; } > RAM AT > XIP
    _data_load = LOADADDR(.data);
    .bss (NOLOAD) : { _bss_start = .; *(.bss*) *(.sbss*) *(COMMON) *(.*_bss) *(.bd_base) . = ALIGN(4); _bss_end = .; } > RAM
    .pool (NOLOAD) : { _pool_start = .; *(.pool*) . = ALIGN(4); _pool_end = .; } > POOL
    .noinit (NOLOAD) : { *(.noinit*) } > NOINIT
    .reverb_noinit (NOLOAD) : { . = ALIGN(4); *(.reverb_noinit*) . = ALIGN(4); } > NOINIT
    /* Separate CPU1 stack in unused retained RAM, before the reserved boot area. */
    .cpu1_stack (NOLOAD) : { . = ALIGN(16); _cpu1_stack_guard = .;
        . += 256; _cpu1_stack_low = .; . += 8192;
        _cpu1_ustack_top = .; . += 512; _cpu1_sstack_top = .; } > NOINIT
    _guard0 = 0x01C74000; _ustack_lo = 0x01C74100; _ustack_top = 0x01C7A000;
    _guard1 = 0x01C7A000; _sstack_lo = 0x01C7A100; _sstack_top = 0x01C7C000;
    /DISCARD/ : { *(.comment) *(.note*) }
}
